
  # CRM System Design Proposal

  This is a code bundle for CRM System Design Proposal. The original project is available at https://www.figma.com/design/KAtuDucijPTgOLMaNiN6Fc/CRM-System-Design-Proposal.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  